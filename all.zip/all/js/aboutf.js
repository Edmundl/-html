$.noConflict()
jQuery('.zy-Slide').zySlide({ speed: 500 })
.css('border', '0px solid blue')
